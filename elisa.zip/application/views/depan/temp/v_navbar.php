<!-- HERO-3
			============================================= -->
<section id="hero-3" class="bg-scroll hero-section division">
    <div class="container">
        <div class="row">


            <!-- HERO TEXT -->
            <div class="col-lg-8 offset-lg-3">
                <div class="hero-txt text-center black-color">

                    <!-- Title -->
                    <!-- <h2 class="h2-xs"><span>2,769 online courses</span> from the leading experts</h2> -->

                    <!-- Text -->
                    <!-- <p class="p-md">Feugiat primis ligula risus auctor egestas augue mauri viverra tortor in iaculis
                        a placerat eugiat mauris ipsum in viverra viverra tortor
                    </p> -->

                    <!--Hero Search Form -->
                    <!-- <form class="hero-form" action="categories-list.html">
                        <div class="input-group">
                            <input type="text" class="form-control" placeholder="What do you want to learn?" aria-label="Search">
                            <span class="input-group-btn">
                                <button type="submit" class="btn"><i class="fa fa-search" aria-hidden="true"></i></button>
                            </span>
                        </div>
                    </form> -->

                </div>
            </div>


        </div> <!-- End row -->
    </div> <!-- End container -->
</section> <!-- END HERO-3 -->